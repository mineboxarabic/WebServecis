export class AuthBookDAO{
    update(){ }
    delete(){ }
    create(){ }
    read(){ }
    findAll(){ }
    deleteAll(){ }
}