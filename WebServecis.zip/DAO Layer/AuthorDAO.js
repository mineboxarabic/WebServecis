export class AuthorDAO  {
    update(){ }
    delete(){ }
    create(){ }
    read(){ }
    findAll(){ }
    deleteAll(){ }
}